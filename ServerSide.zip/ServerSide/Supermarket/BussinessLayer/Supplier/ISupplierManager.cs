﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;

namespace BussinessLayer.Supplier
{
    public interface ISupplierManager
    {
        public List<SupplierDTO> GetAll();
        public int GetSupplierIDByName(string name);

        public bool AddSupplier(SupplierDTO supplier);
        public bool RemoveSupplier(int ID);
        public bool updateSupplier(int ID, SupplierDTO supplier);

        public List<SupplierModel> SearchByName(string Name);
    }
}
