﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;
using DatabaseLayer.Supplier;

namespace BussinessLayer.Supplier
{
    public class SupplierManager : ISupplierManager
    {
        private readonly ISupplierService _service;
        private readonly IMapper _mapper;

        public SupplierManager(ISupplierService service,IMapper mapper)
        {
           _service = service;
            _mapper = mapper;
        }

        public bool AddSupplier(SupplierDTO supplier)
        {

            return _service.AddSupplier(_mapper.Map<SupplierModel>(supplier));
        }

        public List<SupplierDTO> GetAll()
        {
            
         
         return _mapper.Map<List< SupplierDTO>>(_service.GetAll());
            
        }

        public int GetSupplierIDByName(string name)
        {
            return _service.GetSupplierIDByName(name);
        }

        public bool RemoveSupplier(int ID)
        {
            return _service.RemoveSupplier(ID);
        }

        public List<SupplierModel> SearchByName(string Name)
        {
            return _service.SearchByName(Name);
        }

        public bool updateSupplier(int ID, SupplierDTO supplier)
        {
            
            return _service.updateSupplier(ID, _mapper.Map<SupplierModel>(supplier));   
        }
    }
}
