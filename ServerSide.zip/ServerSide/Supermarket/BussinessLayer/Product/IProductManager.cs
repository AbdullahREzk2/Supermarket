﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;

namespace BussinessLayer.Product
{
    public interface IProductManager
    {
        public List<ProductModel>GetProductByName(string productName);
        public List<ProductModel> GetProductByCategory(string CategoryName);
        public List<ProductModel> GetProductBySupplier(string SupplierName);

        public bool AddProduct(ProductDTO product);

        public bool DeleteProduct(int ID);

        public bool UpdateProduct(int ID, ProductDTO product);
    }
}
