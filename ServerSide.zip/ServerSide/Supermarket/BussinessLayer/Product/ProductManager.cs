﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Category;
using DatabaseLayer.Models;
using DatabaseLayer.Product;
using DatabaseLayer.Supplier;

namespace BussinessLayer.Product
{
    public class ProductManager : IProductManager
    {
        private readonly IProductService _service;
        private readonly ICategoryService _categoryService;
        private readonly ISupplierService _supplierService;
        private readonly IMapper _mapper;

        public ProductManager(IProductService service,ICategoryService categoryService,ISupplierService supplierService,IMapper mapper)
        {
           _service = service;
            _categoryService = categoryService;
            _supplierService = supplierService;
            _mapper = mapper;
        }

        public bool AddProduct(ProductDTO product)
        {
            
            return _service.AddProduct(_mapper.Map<ProductModel>(product));
        }

        public bool DeleteProduct(int ID)
        {
           return _service.DeleteProduct(ID);
        }

        public List<ProductModel> GetProductByCategory(string CategoryName)
        {
            int ID=_categoryService.GetIdByCategoryName(CategoryName);
            return _service.GetProductByCategory(ID);
        }

        public List<ProductModel> GetProductByName(string productName)
        {
            return _service.GetProductByName(productName);
        }

        public List<ProductModel> GetProductBySupplier(string SupplierName)
        {
            int ID=_supplierService.GetSupplierIDByName(SupplierName);
            return _service.GetProductBySupplier(ID);
        }

        public bool UpdateProduct(int ID, ProductDTO product)
        {
            
            return _service.UpdateProduct(ID, _mapper.Map<ProductModel>(product));
        }
    }
}
