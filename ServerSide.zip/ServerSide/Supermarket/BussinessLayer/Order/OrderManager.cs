﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using BussinessLayer.Product;
using DatabaseLayer.Models;
using DatabaseLayer.Order;

namespace BussinessLayer.Order
{
    public class OrderManager : IOrderManager
    {
        private readonly IOrderService _service;
        private readonly IMapper _mapper;

        public OrderManager(IOrderService service,IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }
        public int AddOrder(OrderDTO order)
        {
            
            return _service.AddOrder(_mapper.Map<OrderModel>(order));
        }
    }
}
