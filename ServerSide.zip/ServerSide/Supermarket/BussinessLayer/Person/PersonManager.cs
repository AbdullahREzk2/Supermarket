﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Person;

namespace BussinessLayer.Person
{
    public class PersonManager : IPersonManager
    {
        private readonly IPersonService _service;
        private readonly IMapper _mapper;

        public PersonManager(IPersonService service,IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }

        public ProfileDTO GetProfile(int id)
        {

            return _mapper.Map<ProfileDTO>(_service.getProfile(id));
        }

        public bool ChangePassword(int ID, string OldPass, string NewPass)
        {
           return _service.ChangePass(ID, OldPass, NewPass);
        }
    }
}
