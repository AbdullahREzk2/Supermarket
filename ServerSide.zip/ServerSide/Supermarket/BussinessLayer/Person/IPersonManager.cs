﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BussinessLayer.DTOS;

namespace BussinessLayer.Person
{
    public interface IPersonManager
    {
        public ProfileDTO GetProfile(int id);
        public bool ChangePassword(int ID,string OldPass,string NewPass);
    }
}
