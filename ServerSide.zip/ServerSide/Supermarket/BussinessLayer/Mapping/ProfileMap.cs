﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;

namespace BussinessLayer.Mapping
{
    public class ProfileMap:Profile
    {
        public ProfileMap()
        {
            CreateMap<ProfileDTO,PersonModel>().ReverseMap();  
        }
    }
}
