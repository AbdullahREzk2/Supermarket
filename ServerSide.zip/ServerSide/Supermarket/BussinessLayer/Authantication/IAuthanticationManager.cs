﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BussinessLayer.DTOS;

namespace BussinessLayer.Authantication
{
    public interface IAuthanticationManager
    {

        public int Login(LoginDTO login);

        public bool Register(PersonDTO person);
        public bool findEmail(string email);
        public string GetRole(int ID);
    }
}
