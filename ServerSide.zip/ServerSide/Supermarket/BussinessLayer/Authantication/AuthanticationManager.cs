﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Authantication;
using DatabaseLayer.Models;

namespace BussinessLayer.Authantication
{
    public class AuthanticationManager : IAuthanticationManager
    {
        private readonly IAuthanticationService _service;
        private readonly IMapper _mapper;

        public AuthanticationManager(IAuthanticationService service,IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }

       

        public int Login(LoginDTO login)
        {
            return _service.Login(login.Email,login.Password); 
        }

        public bool Register(PersonDTO person)
        {
          bool Search= findEmail(person.Email);
            if (Search==false)
            {
                return _service.Register(_mapper.Map<PersonModel>(person));
            }
            return false;
        }

        public string GetRole(int ID)
        {
            return _service.GetRole(ID);
        }

        public bool findEmail(string email)
        {
            return _service.findEmail(email);
        }
    }
}
