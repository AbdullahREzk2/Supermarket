﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;

namespace BussinessLayer.Category
{
    public interface ICategoryManager
    {

        public List<CategoryModel> GetAll();
        public bool AddCategory(CategoryDTO category);
        public bool RemoveCategory(int ID);

        public bool updateCategory(int ID, CategoryDTO category);

        public List<CategoryModel>SearchByName(string name);
    }
}
