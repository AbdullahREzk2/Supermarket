﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BussinessLayer.DTOS;
using DatabaseLayer.Category;
using DatabaseLayer.Models;

namespace BussinessLayer.Category
{
    public class CategoryManager : ICategoryManager
    {
        private readonly ICategoryService _service;
        private readonly IMapper _mapper;

        public CategoryManager(ICategoryService service,IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }


        public List<CategoryModel> GetAll()
        {
            return _service.GetAll();
        }
        public bool AddCategory(CategoryDTO category)
        {
            
            return _service.Add(_mapper.Map<CategoryModel>(category));
        } 

        public bool RemoveCategory(int ID)
        {
           return _service.Delete(ID);
        }

        public bool updateCategory(int ID, CategoryDTO category)
        {
            
            return _service.Update(ID, _mapper.Map<CategoryModel>(category));
        }

        public List<CategoryModel> SearchByName(string name)
        {
            return _service.SearchByName(name);

        }
    }
}
