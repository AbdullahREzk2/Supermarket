﻿using BussinessLayer.DTOS;
using BussinessLayer.Order;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderManager _manager;

        public OrderController(IOrderManager manager)
        {
            _manager = manager;
        }


        [HttpPost("AddOrder",Name ="AddOrder")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult AddOrder(OrderDTO order)
        {
            if(order == null || string.IsNullOrEmpty(order.Customer_Name) || string.IsNullOrEmpty(order.Customer_Phone) || string.IsNullOrEmpty(order.Payment_Method) ||order.TotalPrice<=0 || order.UserID<=0)
            {
                return BadRequest("Invalid Data Entered !! ");
            }

            int Id=_manager.AddOrder(order);
            if(Id <= 0)
            {
                return NotFound("Failed Process !");
            }
            return Ok(new {ID=Id});
        }

    }
}
