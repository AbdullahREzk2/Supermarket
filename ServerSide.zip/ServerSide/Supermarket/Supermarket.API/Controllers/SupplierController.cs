﻿using BussinessLayer.DTOS;
using BussinessLayer.Supplier;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierManager _manager;

        public SupplierController(ISupplierManager manager)
        {
            _manager = manager;
        }

        [HttpGet("GetAllNames",Name ="GetAllNames")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult getAllNames()
        {
            var Data = _manager.GetAll();
            if(Data == null)
            {
                return NotFound();
            }
            return Ok(Data);
        }

        [HttpGet("GetSupplierIDbyName",Name = "GetSupplierIDbyName")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult GetSupplierIDbyName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return BadRequest("Invalid Data Entered !");
            }
            int ID=_manager.GetSupplierIDByName(name);
            if (ID <= 0)
            {
                return NotFound();
            }
            return Ok(ID);
        }



        [HttpPost("AddSupplier",Name = "AddSupplier")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult AddSupplier(SupplierDTO supplier)
        {
            if(string.IsNullOrEmpty(supplier.Name) || string.IsNullOrEmpty(supplier.Phone)|| string.IsNullOrEmpty(supplier.Address))
            {
                return BadRequest("Invalid Data Entered !");
            } 
            bool Added=_manager.AddSupplier(supplier);
            if (Added)
            {
                return Ok("Added Successfuly !");
            }
            return NotFound("Failed To Add !");
        }




        [HttpDelete("RemoveSupplier",Name = "RemoveSupplier")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult RemoveSupplier(int ID)
        {
            if(ID <= 0)
            {
                return BadRequest("Invalid Id Entered !");
            }
            bool Removed=_manager.RemoveSupplier(ID);
            if (Removed)
            {
                return Ok("Removed Successfully !");
            }
            return NotFound("Failed !");
        }



        [HttpPut("updateSupplier",Name = "updateSupplier")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult UpdateSupplier(int ID,SupplierDTO supplier)
        {
            if (string.IsNullOrEmpty(supplier.Name) || string.IsNullOrEmpty(supplier.Phone) || string.IsNullOrEmpty(supplier.Address))
            {
                return BadRequest("Invalid Data Entered !");
            }
            bool Updated=_manager.updateSupplier(ID, supplier);
            if(Updated)
            {
                return Ok("Updated Successfully !");
            }
            return NotFound("Failed To Updated !");
        }


        [HttpGet("SearchByName",Name = "SearchBySupplierName")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
         
        public ActionResult SearchByName(string Name)
        {
            if (string.IsNullOrEmpty(Name))
            {
                return BadRequest("Invalid Data entered !");
            }
            var Data=_manager.SearchByName(Name);
            if (Data==null)
            {
                return NotFound("Data Not Found !");
            }
            return Ok(Data);
        } 


    }
}
