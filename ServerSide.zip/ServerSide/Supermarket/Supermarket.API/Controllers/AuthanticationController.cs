﻿using BussinessLayer.Authantication;
using BussinessLayer.DTOS;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthanticationController : ControllerBase
    {
        private readonly IAuthanticationManager _manager;

        public AuthanticationController(IAuthanticationManager manager)
        {
           _manager = manager;
        }


        [HttpPost("Login",Name ="Login")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult Login(LoginDTO login)
        {
            if(login == null)
            {
                return BadRequest("Invalid Data Entered !!");
            }
            int id = _manager.Login(login);
            if(id == 0)
            {
                return NotFound("User Not Found !!");
            }
            string role = _manager.GetRole(id);
            return Ok(new { ID = id, Role = role });
        }


        [HttpPost("Register",Name ="Register")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult Register(PersonDTO person)
        {
            if(person == null || string.IsNullOrEmpty(person.FirstName) || string.IsNullOrEmpty(person.LastName) || string.IsNullOrEmpty(person.Email) || string.IsNullOrEmpty(person.Password) || string.IsNullOrEmpty(person.Number) || string.IsNullOrEmpty(person.Role))
            {
                return BadRequest("Invalid Data Entered !!");
            }
            bool Added=_manager.Register(person);
            if (Added)
            {
                return Ok(new { Message = "Successful Register " });
            }
            return NotFound("Failed To Register !");
        }



    }
}
