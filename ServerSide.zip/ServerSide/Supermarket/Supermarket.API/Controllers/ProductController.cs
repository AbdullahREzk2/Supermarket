﻿using BussinessLayer.DTOS;
using BussinessLayer.Product;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductManager _manager;

        public ProductController(IProductManager manager)
        {
            _manager = manager;
        }


        [HttpGet("GetProductByName",Name = "GetProductByName")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult GetProductByName(string productName)
        {
            if(string.IsNullOrEmpty(productName))
            {
                return BadRequest("Invalid Data Entered ! ");
            }

            var Products=_manager.GetProductByName(productName);
            if(Products == null)
            {
                return NotFound("Product Not Found !");
            }
            return Ok(Products);
        }


        [HttpPost("AddProduct",Name ="AddProdcut")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult AddProduct(ProductDTO product)
        {
            if(string.IsNullOrEmpty(product.Name)||product.Price<=0|| product.NumOfStock <= 0 || product.Category_ID <= 0 || product.Supplier_ID <= -0)
            {
                return BadRequest("Invalid Data Entered ! ");
            }
            bool Added=_manager.AddProduct(product);
            if (Added)
            {
                return Ok("Added Successfully !");
            }
            return NotFound("Failed To Add !");
        }

        [HttpPut("UpdateProduct",Name ="UpdateProdcut")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult UpdateProduct(int Id,ProductDTO product)
        {
            if(Id<=0 || string.IsNullOrEmpty(product.Name))
            {
                return BadRequest("Invalid Data Entered !");
            }
            bool updated=_manager.UpdateProduct(Id, product);
            if(updated)
            {
                return Ok("Updated Successfully !");
            }
            return NotFound("Failed To Update !");
        }

        [HttpDelete("DeleteProduct",Name ="DeleteProduct")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult DeleteProduct(int ID)
        {
            if (ID <= 0)
            {
                return BadRequest("Invalid Data ! ");
            }
            bool deleted=_manager.DeleteProduct(ID);
            if (deleted)
            {
                return Ok("Deleted Successfully !");
            }
            return NotFound("Failed To Delete !");
        }


        [HttpGet("GetProductByCategory",Name = "GetProductByCategory")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult GetProductByCategory(string categoryName)
        {
            if (string.IsNullOrEmpty(categoryName))
            {
                return BadRequest("Invalid Data Entered !");
            }
            var Categories=_manager.GetProductByCategory(categoryName);
            if(Categories == null)
            {
                return NotFound("No Data !");
            }
            return Ok(Categories);
        }

        [HttpGet("GetProductBySupplier",Name = "GetProductBySupplier")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult GetProductsBySupplier(string supplierName)
        {
            if(string.IsNullOrEmpty(supplierName))
            {
                return BadRequest("Invalid Data Entered !");
            }
            var Products=_manager.GetProductBySupplier(supplierName);
            if(Products == null)
            {
                return NotFound("No Data !");
            }
            return Ok(Products);
        }
    }
}
