﻿using BussinessLayer.Category;
using BussinessLayer.DTOS;
using DatabaseLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryManager _manager;

        public CategoryController(ICategoryManager manager)
        {
            _manager = manager;
        }


        [HttpGet("GetAll",Name ="GetAll")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]

        public ActionResult <List<CategoryModel>> GetAll()
        {
            var Data = _manager.GetAll();
            if(Data == null)
            {
                return NotFound("Data Not Found !");
            }
            return Ok(Data);
        }


        [HttpPost("AddCategory",Name = "AddCategory")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult AddCategory(CategoryDTO category)
        {
            if(string.IsNullOrEmpty(category.Name))
            {
                return BadRequest("Invalid Data Entered ! ");
            }
         bool Added=_manager.AddCategory(category);
            if (Added)
            {
                return Ok("Added Successfully !");
            }
            return NotFound("Failed To Add !");
        }


        [HttpDelete("DeleteCategory/{ID}", Name = "DeleteCategory")]

        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult DeleteCategory(int ID)
        {
            if (ID <= 0)
            {
                return BadRequest("Invalid Data Entered!");
            }

            bool Deleted = _manager.RemoveCategory(ID);
            if (Deleted)
            {
                return Ok("Deleted Successfully!");
            }

            return NotFound("Not Found!");
        }


        [HttpPut("UpdateCategory/{ID}", Name = "UpdateCategory")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult UpdateCategory(int ID, CategoryDTO category)
        {
            if (string.IsNullOrEmpty(category.Name) || ID<=0 )
            {
                return BadRequest("Invalid Data Entered ! ");
            }

            bool Updated = _manager.updateCategory(ID, category);
            if(Updated)
            {
                return Ok("Updated Successfully ! ");
            }
            return NotFound("Failed To Update ! ");
        }


        [HttpGet("SearchByname",Name ="SearchByname")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult <List<CategoryModel>> Search(string Name)
        {
            if (string.IsNullOrEmpty(Name))
            {
                return BadRequest("Invlid Data Entered ! ");
            }
            var Data = _manager.SearchByName(Name);
            if (Data == null)
            {
                return NotFound("No Data !");
            }
            return Ok(Data);
        }
    }
}
