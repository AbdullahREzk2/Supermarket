﻿using BussinessLayer.Person;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly IPersonManager _manager;

        public ProfileController(IPersonManager manager)
        {
           _manager = manager;
        }


        [HttpGet("GetProfile",Name ="GetProfile")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult GetProfile(int ID)
        {
            if (ID <= 0)
            {
                return BadRequest("Invalid Data Entered ! ");
            }
            var Profile=_manager.GetProfile(ID);
            if (Profile.FirstName == null)
            {
                return NotFound("Not Found !");
            }
            return Ok(Profile);
        }

        [HttpPost("ChangePass",Name ="ChangePass")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public ActionResult ChangePassword(int ID,string oldPass,string NewPass)
        {
            if(ID <= 0 || string.IsNullOrEmpty(oldPass) || string.IsNullOrEmpty(NewPass))
            {
                return BadRequest("Invalid Data Entered !");
            } 
            bool Chnaged=_manager.ChangePassword(ID,oldPass,NewPass);
            if(Chnaged)
            {
                return Ok("Chnaged Successfully !");
            }
            return NotFound("Failed !");
        }
    }
}
