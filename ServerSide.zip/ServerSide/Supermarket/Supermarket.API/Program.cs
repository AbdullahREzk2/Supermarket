using BussinessLayer.Authantication;
using BussinessLayer.Category;
using BussinessLayer.Mapping;
using BussinessLayer.Order;
using BussinessLayer.Person;
using BussinessLayer.Product;
using BussinessLayer.Supplier;
using DatabaseLayer;
using DatabaseLayer.Authantication;
using DatabaseLayer.Category;
using DatabaseLayer.Order;
using DatabaseLayer.Person;
using DatabaseLayer.Product;
using DatabaseLayer.Supplier;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddScoped<dbHelper>();
builder.Services.AddScoped<IAuthanticationService,AuthanticationService>();
builder.Services.AddScoped<IAuthanticationManager, AuthanticationManager>();
builder.Services.AddAutoMapper(typeof(PersonMap));
builder.Services.AddScoped<IProductService,ProductService>();
builder.Services.AddScoped<IProductManager,ProductManager>();
builder.Services.AddAutoMapper(typeof(ProductMap));
builder.Services.AddScoped<IOrderService,OrderService>();
builder.Services.AddScoped<IOrderManager,OrderManager>();
builder.Services.AddAutoMapper(typeof(OrderMap));
builder.Services.AddScoped<ICategoryService,CategoryService>();
builder.Services.AddScoped<ICategoryManager, CategoryManager>();
builder.Services.AddAutoMapper(typeof(CategoryMap));
builder.Services.AddScoped<ISupplierService,SupplierService>();
builder.Services.AddScoped<ISupplierManager,SupplierManager>();
builder.Services.AddAutoMapper(typeof(SupplierMap));
builder.Services.AddScoped<IPersonService,PersonService>();
builder.Services.AddScoped<IPersonManager,PersonManager>();
builder.Services.AddAutoMapper(typeof(ProfileMap));



builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
