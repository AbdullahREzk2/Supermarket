﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Person
{
    public interface IPersonService
    {
        public PersonModel getProfile(int ID);

        public bool ChangePass(int ID,string OldPass,string NewPass);
    }
}
