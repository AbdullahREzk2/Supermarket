﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Person
{
    public class PersonService : IPersonService
    {
        private readonly dbHelper _helper;

        public PersonService(dbHelper helper)
        {
            _helper = helper;
        }

       

        public PersonModel getProfile(int ID)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select * from [User] where ID =@id";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@id", ID);
                    PersonModel model = new PersonModel();
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        model.Person_Id=(int)reader["ID"];
                        model.FirstName = reader["Fname"].ToString();
                        model.LastName = reader["LName"].ToString();
                        model.Email = reader["Email"].ToString();
                        model.Password = reader["Password"].ToString();
                        model.Role=reader["Role"].ToString();
                        model.Number = reader["Number"].ToString();
                    }
                    return model;
                }
            }
        }

        public bool ChangePass(int ID, string OldPass, string NewPass)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "update [User]" +
                                "set Password =@newPass" +
                                " where ID=@id and Password=@oldpass";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@newPass", NewPass);
                    command.Parameters.AddWithValue("@id", ID);
                    command.Parameters.AddWithValue("@oldpass", OldPass);
                    connection.Open();

                    int rowsAffected= command.ExecuteNonQuery();
                    return rowsAffected > 0?true:false;
                }
            }
        }

    }
}
