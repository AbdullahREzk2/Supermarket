﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Order
{
    public class OrderService : IOrderService
    {
        private readonly dbHelper _helper;

        public OrderService(dbHelper helper)
        {
            _helper = helper;
        }



        public int AddOrder(OrderModel order)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "INSERT INTO [Order] (Customer_Name, Customer_Phone, Payment_Method, TotalPrice, UserID) " +
               "OUTPUT INSERTED.ID " +
               "VALUES (@name, @phone, @method, @price, @userId)";

                using (SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name",order.Customer_Name);
                    command.Parameters.AddWithValue("@phone", order.Customer_Phone);
                    command.Parameters.AddWithValue("@method", order.Payment_Method);
                    command.Parameters.AddWithValue("@price", order.TotalPrice);
                    command.Parameters.AddWithValue("@userId", order.UserID);


                    connection.Open();

                    int Id=(int)command.ExecuteScalar();
                    return Id!=null?Id : 0;

                    
                }
            }
        }




    }
}
