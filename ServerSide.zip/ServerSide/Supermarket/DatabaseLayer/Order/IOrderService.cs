﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Order
{
    public interface IOrderService
    {
        public int AddOrder(OrderModel order);
        
    }
}
