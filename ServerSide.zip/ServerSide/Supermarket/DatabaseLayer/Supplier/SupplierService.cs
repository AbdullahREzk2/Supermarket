﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Supplier
{
    public class SupplierService : ISupplierService
    {
        private readonly dbHelper _helper;

        public SupplierService(dbHelper helper)
        {
           _helper = helper;
        }

        

        public List<SupplierModel> GetAll()
        {
            using(SqlConnection connection=new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "select * from Supplier";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    List<SupplierModel> AllSuppliers= new List<SupplierModel>();
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        AllSuppliers.Add(new SupplierModel()
                        {
                            ID = (int)reader["ID"],
                            Name = reader["Name"].ToString(),
                            Phone = reader["Phone"].ToString(),
                            Address = reader["Address"].ToString()
                        });
                    }
                    return AllSuppliers;

                }
            }
        }


        public int GetSupplierIDByName(string name)
        {
           using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select ID from Supplier where Name=@name";
                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    connection.Open();

                    object Result= command.ExecuteScalar();

                    return Result!=null ?Convert.ToInt32 (Result) : 0;
                }
            }
        }


        public bool AddSupplier(SupplierModel supplier)
        {
            using (SqlConnection connection = new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "insert into Supplier (Name,Phone,Address)" +
                    " values" +
                    "(@name,@Phone,@address)";
                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", supplier.Name);
                    command.Parameters.AddWithValue("@Phone", supplier.Phone);
                    command.Parameters.AddWithValue("@address", supplier.Address);

                    connection.Open();

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0 ? true : false;
                }
            }
        }


        public bool RemoveSupplier(int ID)
        {
                using (SqlConnection connection = new SqlConnection(_helper.GetconnectionString()))
                {
                string Query = "delete from Supplier where ID=@id";



                    using (SqlCommand command = new SqlCommand(Query, connection))
                    {
                        command.Parameters.AddWithValue("@id",ID);
                        

                        connection.Open();

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0 ? true : false;
                    }
                }
            }
        

        public bool updateSupplier(int ID, SupplierModel supplier)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "update Supplier" +
                              " set Name=@name," +
                              "Phone=@phone," +
                              "Address=@address" +
                              " where ID=@id";
                using(SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", supplier.Name);
                    command.Parameters.AddWithValue("@phone", supplier.Phone);
                    command.Parameters.AddWithValue("@address", supplier.Address);
                    command.Parameters.AddWithValue("@id",ID);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected>0?true:false;

                }
            }
        }

        public List<SupplierModel> SearchByName(string Name)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select * from Supplier where Name like @name";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", $"%{Name}%");

                    List<SupplierModel> Suppliers=  new List<SupplierModel>();

                    connection.Open();

                    SqlDataReader reader= command.ExecuteReader();
                    while (reader.Read())
                    {
                        Suppliers.Add(new SupplierModel()
                        {
                            ID=(int)reader["ID"],
                            Name= reader["Name"].ToString(),
                            Phone = reader["Phone"].ToString(),
                            Address=reader["address"].ToString(),
                        });
                    }
                    return Suppliers;
                }
            }
        }
    }
}
