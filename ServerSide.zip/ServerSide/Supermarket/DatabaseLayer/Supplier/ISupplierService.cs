﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Supplier
{
    public interface ISupplierService
    {
        public List<SupplierModel> GetAll();
        public int GetSupplierIDByName(string name);

        public bool AddSupplier(SupplierModel supplier);
        public bool RemoveSupplier(int ID);
        public bool updateSupplier(int ID,SupplierModel supplier);

        public List<SupplierModel> SearchByName(string Name);
    }
}
