﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Category
{
    public class CategoryService : ICategoryService
    {
        private readonly dbHelper _helper;

        public CategoryService(dbHelper helper)
        {
            _helper = helper;
        }

        public List<CategoryModel> GetAll()
        {
         using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select ID,Name from Category";
             using(SqlCommand command=new SqlCommand(Query,connection))
                {
                    List<CategoryModel>GetAll= new List<CategoryModel>();
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        GetAll.Add(new CategoryModel()
                        {
                            Id = (int)reader["ID"],
                            Name = reader["Name"].ToString()
                        });
                    }

                    return GetAll;
                }
            }   
        }

        public bool Add(CategoryModel category)
        {
           using(SqlConnection connection=new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "insert into Category (Name) values (@name)";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", category.Name);

                    connection.Open();
                    int rowsAffected=command.ExecuteNonQuery();

                    return rowsAffected > 0?true:false;
                }
            }
        }

        public bool Delete(int ID)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "delete from Category where id =@id";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@id", ID);

                    connection.Open();
                    int rowsAffected=command.ExecuteNonQuery();
                    return rowsAffected>0?true:false;
                }
            }
        }

        public bool Update(int Id, CategoryModel category)
        {
            using(SqlConnection connection =new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "update category set Name = @name where ID = @id";

                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("name", category.Name);
                    command.Parameters.AddWithValue("@id", Id);
                    connection.Open();

                    int rowsAffected=command.ExecuteNonQuery();

                    return rowsAffected>=0?true:false;
                }
            }
        }

        public List<CategoryModel> SearchByName(string Name)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select ID,Name from Category where Name like @name";
                using(SqlCommand command=new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@name", $"%{Name}%");

                    connection.Open();

                    List<CategoryModel> AllCategory = new List<CategoryModel>();
                    SqlDataReader reader=command.ExecuteReader();
                    while (reader.Read())
                    {
                        AllCategory.Add(new CategoryModel()
                        {
                            Id = (int)reader["ID"],
                            Name = reader["Name"] .ToString()
                        });
                    }
                    return AllCategory;
                }
            }
        }

        public int GetIdByCategoryName(string CategoryName)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select ID from Category where Name=@name";
                using(SqlCommand command=new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@name", CategoryName);
                    connection.Open();

                    object Result=command.ExecuteScalar();

                    return Result!=null?Convert.ToInt32(Result) : 0;
                }
            }
        }
    }
}
