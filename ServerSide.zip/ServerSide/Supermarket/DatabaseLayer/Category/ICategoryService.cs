﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Category
{
    public interface ICategoryService
    {
        public List<CategoryModel> GetAll();
        public bool Add(CategoryModel category);
        public bool Update(int Id,CategoryModel category);
        public bool Delete(int Id);

        public List<CategoryModel> SearchByName(string Name);


        public int GetIdByCategoryName(string CategoryName);
    }
}
