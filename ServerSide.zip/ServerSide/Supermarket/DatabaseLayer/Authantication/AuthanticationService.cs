﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Authantication
{
    public class AuthanticationService : IAuthanticationService
    {
        private readonly dbHelper _helper;

        public AuthanticationService(dbHelper helper)
        {
            _helper = helper;
        }

       

        public int Login(string Email, string Password)
        {
            using (SqlConnection connection = new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select id from [User] where Email =@email and Password =@pass";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@email", Email);
                    command.Parameters.AddWithValue("@pass", Password);

                    connection.Open();

                    object ID=command.ExecuteScalar();

                    return ID!=null?Convert.ToInt32(ID):0;
                }
            }
        }

        public bool Register(PersonModel person)
        {
            using(SqlConnection connection=new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "insert into [User] (Fname,LName,Email,Password,Number,Role) values(@fname,@lname,@email,@pass,@number,@role)";
                using(SqlCommand command=new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@fname",person.FirstName);
                    command.Parameters.AddWithValue("@lname", person.LastName);
                    command.Parameters.AddWithValue("@email", person.Email);
                    command.Parameters.AddWithValue("@pass", person.Password);
                    command.Parameters.AddWithValue("@number", person.Number);
                    command.Parameters.AddWithValue("@role", person.Role);


                    connection.Open();

                    int rowsAffected=command.ExecuteNonQuery();

                    return rowsAffected>0?true:false;
                }
            }
        }

        public bool findEmail(string Email)
        {
            using(SqlConnection connection =new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "select count(*) from [User] where Email=@email";
                using(SqlCommand command =new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@email", Email);

                    connection.Open();

                    object count=command.ExecuteScalar();
                    return (int)count>0?true:false;
                }
            }
        }

        public string GetRole(int ID)
        {
            using(SqlConnection connection =new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "select Role from [User] where ID=@id";
                using(SqlCommand command=new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@id", ID);

                    connection.Open();
                    object Role=command.ExecuteScalar();

                    return Role.ToString();
                }
            }
        }


    }
}
