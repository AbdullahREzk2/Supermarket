﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Authantication
{
    public interface IAuthanticationService
    {
        public int Login(string Email, string Password);
        public bool Register(PersonModel person);
        public bool findEmail(string Email);
        public string GetRole(int ID);
    }
}
