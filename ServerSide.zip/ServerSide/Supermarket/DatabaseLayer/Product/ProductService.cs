﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;
using Microsoft.Data.SqlClient;

namespace DatabaseLayer.Product
{
    public class ProductService : IProductService
    {
        private readonly dbHelper _helper;

        public ProductService(dbHelper helper)
        {
            _helper = helper;
        }

        public bool AddProduct(ProductModel product)
        {
            using (SqlConnection connection = new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "insert into Product " +
                               "(Name,Price,NumOfStock,CategoryID,SupplierID)" +
                               "values(@name,@price,@numofstock,@categoryID,@supplierId)";
                using(SqlCommand command=new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name", product.Name);
                    command.Parameters.AddWithValue("@price", product.Price);
                    command.Parameters.AddWithValue("@numofstock", product.NumOfStock);
                    command.Parameters.AddWithValue("@categoryID", product.Category_ID);
                    command.Parameters.AddWithValue("@supplierId", product.Supplier_ID);

                    connection.Open();

                    int rowsAffected=command.ExecuteNonQuery();

                    return rowsAffected > 0?true:false;
                }
            }

        }

        public bool DeleteProduct(int ID)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "delete from Product where ID=@id";
                using(SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@id", ID);

                    connection.Open();
                    int rowsAffected=command.ExecuteNonQuery();
                    return rowsAffected>0?true:false;
                }
            }
        }

        public List<ProductModel> GetProductByCategory(int CategoryID)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "select * from Product where CategoryID=@id";
                using(SqlCommand command =new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@id", CategoryID);
                    connection.Open();
                    List<ProductModel> products = new List<ProductModel>();

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        products.Add(new ProductModel(){
                            Product_ID=(int)reader["ID"],
                            Name = reader["Name"].ToString(),
                            Price = (int)reader["Price"],
                            NumOfStock = (int)reader["NumOfstock"],
                            Category_ID = (int)reader["CategoryID"],
                            Supplier_ID = (int)reader["supplierID"]
                        });
                    }
                    return products;
                }
            }
        }

        public List<ProductModel> GetProductByName(string Name)
        {
            using(SqlConnection connection=new SqlConnection (_helper.GetconnectionString()))
            {
                string Query = "SELECT * FROM Product WHERE Name LIKE @name";
                using(SqlCommand command=new SqlCommand (Query, connection))
                {
                    command.Parameters.AddWithValue("@name", $"%{Name}%");

                    List<ProductModel> AllProducts = new List<ProductModel>();
                    connection.Open ();
                    SqlDataReader reader = command.ExecuteReader ();
                    while (reader.Read ())
                    {
                        AllProducts.Add(new ProductModel{
                            Product_ID = (int)reader["ID"],
                            Name = reader["Name"].ToString(),
                            Price = (int)reader["Price"],
                            Image = reader["Image"].ToString(),
                            NumOfStock = (int)reader["NumOfStock"],
                            Category_ID = (int)reader["CategoryID"],
                            Supplier_ID = (int)reader["SupplierID"],
                            UnitofPrize = reader["UnitofPrize"] != DBNull.Value ? Convert.ToInt32(reader["UnitofPrize"]) : 0

                        });
                    }
                    return AllProducts;
                }
            }
        }

        public List<ProductModel> GetProductBySupplier(int SupplierID)
        {
          using (SqlConnection connection = new SqlConnection(_helper.GetconnectionString()))
          {
            string Query = "select * from Product where SupplierID=@id";
            using (SqlCommand command = new SqlCommand(Query, connection))
            {
             command.Parameters.AddWithValue("@id", SupplierID);
             connection.Open();
             List<ProductModel> products = new List<ProductModel>();

              SqlDataReader reader = command.ExecuteReader();
              while (reader.Read())
              {
                  products.Add(new ProductModel()
                  {
                      Product_ID = (int)reader["ID"],
                      Name = reader["Name"].ToString(),
                      Price = (int)reader["Price"],
                      NumOfStock = (int)reader["NumOfstock"],
                      Category_ID = (int)reader["CategoryID"],
                      Supplier_ID = (int)reader["supplierID"]
                  });
              }
              return products;
            }
          }
        }
        

        public bool UpdateProduct(int ID, ProductModel product)
        {
            using(SqlConnection connection=new SqlConnection(_helper.GetconnectionString()))
            {
                string Query = "update Product set" +
                               " Name=@name,Price=@price,NumOfStock=@num,CategoryID=@catId,SupplierID=@supID " +
                               " where ID=@id";
                using(SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@name",product.Name);
                    command.Parameters.AddWithValue("@price", product.Price);
                    command.Parameters.AddWithValue("@num", product.NumOfStock);
                    command.Parameters.AddWithValue("@catId", product.Category_ID);
                    command.Parameters.AddWithValue("@supID", product.Supplier_ID);
                    command.Parameters.AddWithValue("@id", ID);


                    connection.Open();

                    int rowsAffected=command.ExecuteNonQuery();
                    return rowsAffected > 0?true:false;
                }
            }
        }



    }
}
