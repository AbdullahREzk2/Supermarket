﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseLayer.Models;

namespace DatabaseLayer.Product
{
    public interface IProductService
    {
        public List<ProductModel> GetProductByName(string Name);

        public List<ProductModel> GetProductByCategory(int CategoryID);
        public List<ProductModel> GetProductBySupplier(int SupplierID);

        public bool AddProduct(ProductModel product);

        public bool DeleteProduct(int ID);

        public bool UpdateProduct(int ID,ProductModel product);
    }
}
